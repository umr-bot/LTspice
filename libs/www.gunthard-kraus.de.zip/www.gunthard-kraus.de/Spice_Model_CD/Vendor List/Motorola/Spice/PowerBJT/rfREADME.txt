 These SPICE models represent "typical" RF low-power discrete parts,
 based on specifications published in the RF Device Databook.
 These models will lead to accurate simulations under most conditions.
 There are inherent problems with the SPICE Gummel-Poon bipolar
 transistor model: poor quasi-saturation modeling, lack of die
 self-heating, and minimal modeling of distributed base-collector effects.


